import { ParsedBOQItem } from "./boqReader";

export interface WBSNode {

    bill: string;

    section: string;

}

export function buildWBS(
    items: ParsedBOQItem[]
): WBSNode[] {

    const result: WBSNode[] = [];

    const used = new Set<string>();

    items.forEach(item => {

        if (
            item.rowType === "ITEM" &&
            item.bill !== ""
        ) {

            const key =
                item.bill + "|" + item.section;

            if (!used.has(key)) {

                used.add(key);

                result.push({

                    bill: item.bill,

                    section: item.section

                });

            }

        }

    });

    return result;

}