import { BOQRow, ParsedBOQItem } from "./boqReader";

export function parseBOQ(
    rows: BOQRow[]
): ParsedBOQItem[] {

    const items: ParsedBOQItem[] = [];

    let currentBill = "";
    let currentSection = "";

    rows.forEach(row => {

        const values = row.cells.map(c => String(c.value ?? "").trim());

        const rowText = values.join(" ").toLowerCase();

        let rowType: ParsedBOQItem["rowType"] = "ITEM";

        // Skip empty rows
        if (values.every(v => v === "")) {
            return;
        }

        // BILL
        if (values.some(v => /^bill\s*\d+/i.test(v))) {

            const billCell =
                values.find(v => /^bill\s*\d+/i.test(v))!;

            currentBill = billCell;

            currentSection = "";

            rowType = "BILL";
        }

        // SUMMARY
        else if (
            rowText.includes("carried to") ||
            rowText.includes("total of page") ||
            rowText.includes("grand total") ||
            rowText.includes("subtotal")
        ) {

            rowType = "SUMMARY";
        }

        // HEADER
        else if (
            rowText.includes("item") &&
            rowText.includes("description") &&
            rowText.includes("quantity")
        ) {

            rowType = "HEADER";
        }

        // SECTION
        else if (
            values[0] === "" &&
            values[1] !== "" &&
            values[2] === "" &&
            values[3] === ""
        ) {

            rowType = "SECTION";

            currentSection = values[1];
        }

        // ITEM
        else {

            rowType = "ITEM";
        }

        const itemNo = values[0];

        const description = values[1] || "";

        let quantity: number | null = null;

        if (values[2] !== "" && !isNaN(Number(values[2]))) {
            quantity = Number(values[2]);
        }

        const unit = values[3] || "";

        let rate: number | null = null;

        if (values[4] !== "" && !isNaN(Number(values[4]))) {
            rate = Number(values[4]);
        }

        let amount: number | null = null;

        if (values[5] !== "" && !isNaN(Number(values[5]))) {
            amount = Number(values[5]);
        }

        if (description === "") {
            return;
        }

        if (rowType === "SUMMARY") {
            return;
        }

        items.push({

            sheet: row.sheet,

            bill: currentBill,

            section: currentSection,

            itemNo,

            description,

            quantity,

            unit,

            rate,

            amount,

            rowType

        });

    });

    console.log("Parsed Item Count:", items.length);

    return items;

}