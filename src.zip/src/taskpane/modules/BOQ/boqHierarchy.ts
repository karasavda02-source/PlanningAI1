import { ParsedBOQItem } from "./boqReader";

export interface BOQSection {
    name: string;
    items: ParsedBOQItem[];
}

export interface BOQBill {
    name: string;
    sections: BOQSection[];
}

export function buildBOQHierarchy(
    items: ParsedBOQItem[]
): BOQBill[] {

    const bills: BOQBill[] = [];

    let currentBill: BOQBill | null = null;
    let currentSection: BOQSection | null = null;

    for (const item of items) {

        switch (item.rowType) {

            case "BILL":

                currentBill = {
                    name: item.description,
                    sections: []
                };

                bills.push(currentBill);

                currentSection = null;

                break;

            case "SECTION":

                if (!currentBill) continue;

                currentSection = {
                    name: item.description,
                    items: []
                };

                currentBill.sections.push(currentSection);

                break;

            case "ITEM":

                if (!currentBill) continue;

                // Some BOQs have items before the first section.
                if (!currentSection) {

                    currentSection = {
                        name: "General",
                        items: []
                    };

                    currentBill.sections.push(currentSection);

                }

                currentSection.items.push(item);

                break;

            default:
                break;
        }

    }

    return bills;
}