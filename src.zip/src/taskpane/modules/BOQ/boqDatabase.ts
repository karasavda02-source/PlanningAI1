import { ParsedBOQItem } from "./boqReader";

export interface BOQDatabase {

    items: ParsedBOQItem[];

    totalItems: number;

    totalQuantity: number;

    totalAmount: number;

}

export function buildBOQDatabase(
    items: ParsedBOQItem[]
): BOQDatabase {

    let totalQuantity = 0;

    let totalAmount = 0;

    items.forEach(item => {

        if (item.quantity !== null) {
            totalQuantity += item.quantity;
        }

        if (item.amount !== null) {
            totalAmount += item.amount;
        }

    });

    return {

        items,

        totalItems: items.length,

        totalQuantity,

        totalAmount

    };

}