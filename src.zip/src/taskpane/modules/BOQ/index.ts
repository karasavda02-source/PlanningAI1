import * as XLSX from "xlsx";
import { readBOQWorkbook } from "./boqReader";
import { cleanBOQRows } from "./boqCleaner";
import { parseBOQ } from "./boqParser";
import { buildBOQHierarchy } from "./boqHierarchy";
import { buildBOQDatabase } from "./boqDatabase";
import { exportBOQDatabase } from "./boqExcel";
import { buildWBS } from "./boqWBS";
import { PlanningEngine } from "../AI/PlanningEngine/planningEngine";
import { ProjectContext } from "../AI/projectContext";
export function loadBOQPage() {

    const app = document.getElementById("app");

    if (!app) return;

    app.innerHTML = `
    
        <div class="header">
            <h1>BOQ Import</h1>
            <p>Import and analyze Bill of Quantities</p>
        </div>

        <div class="card">

            <h3>Select BOQ File</h3>

            <input
                type="file"
                id="boqFile"
                accept=".xlsx,.xls"
            >

            <br><br>

            <button id="importBOQ">
                Import BOQ
            </button>

            <br><br>

            <div id="boqStatus"></div>

        </div>

    `;

    document
        .getElementById("importBOQ")
        ?.addEventListener("click", importBOQ);

}

async function importBOQ() {

    const fileInput = document.getElementById("boqFile") as HTMLInputElement;

    if (!fileInput.files || fileInput.files.length === 0) {
        alert("Please select a BOQ file.");
        return;
    }

    const file = fileInput.files[0];

    const reader = new FileReader();

    reader.onload = async (event) => {

        const data = event.target?.result as ArrayBuffer;

        const boqRows = readBOQWorkbook(data);
        console.log(
    "Reader Rows Before Cleaning",
    boqRows.length
);

        let totalSheets = new Set(
    boqRows.map(row => row.sheet)
).size;
console.log(
    "Sending Rows To Cleaner",
    boqRows.length
);
const cleanedRows = cleanBOQRows(boqRows);
const removedRows =
    boqRows.length - cleanedRows.length;
const parsedItems = parseBOQ(cleanedRows);

console.log("Parsed Items", parsedItems);
console.log("Parsed Item Count:", parsedItems.length);
const context: ProjectContext = {

    projectName: "Imported Project",

    boq: parsedItems,

    drawings: [],

    specifications: [],

    contracts: []

};

const planner = new PlanningEngine();

await planner.analyzeProject(context);

const boqDatabase = buildBOQDatabase(parsedItems);
console.log("BOQ Database", boqDatabase);

const boqHierarchy = buildBOQHierarchy(parsedItems);
console.log("BOQ Hierarchy", boqHierarchy);
await exportBOQDatabase(parsedItems);
const wbs = buildWBS(parsedItems);

console.log("Generated WBS", wbs);
const activities =
    await generateActivities(parsedItems);

console.log(
    "AI Generated Activities",
    aiActivities
);
console.log(
    "Parsed Items",
    parsedItems
);

console.log(
    "Parsed Item Count:",
    parsedItems.length
);

console.log(
    "BOQ Analysis",
    {
        OriginalRows: boqRows.length,
        CleanedRows: cleanedRows.length,
        RemovedRows: removedRows
    }
);


let allRows:any[][] = [];


cleanedRows.forEach(row => {

    allRows.push(
        row.cells.map(cell => cell.value)
    );

});

        console.log(
    "Cleaned BOQ Rows",
    allRows
);
        // Remove completely empty rows

allRows = allRows.filter(row => {

    return row.some(cell => 
        cell !== null &&
        cell !== undefined &&
        cell !== ""
    );

});
        await Excel.run(async (context) => {

    let sheet = context.workbook.worksheets.getItemOrNullObject("_AI_BOQ");

    sheet.load("name");

    await context.sync();


    if(sheet.isNullObject){

        sheet = context.workbook.worksheets.add("_AI_BOQ");

    }


    const rowCount = allRows.length;

    const columnCount = Math.max(
        ...allRows.map(row => row.length)
    );


    const finalData = allRows.map(row => {

        let newRow = [...row];

        while(newRow.length < columnCount){

            newRow.push("");

        }

        return newRow;

    });


    const range = sheet
        .getRangeByIndexes(
            0,
            0,
            rowCount,
            columnCount
        );


    range.values = finalData;


    range.format.autofitColumns();


    await context.sync();


});

        const status = document.getElementById("boqStatus");

        if (status) {

            status.innerHTML = `

<b>BOQ Import Successful</b><br><br>

Sheets:
${totalSheets}<br>

Original Rows:
${boqRows.length}<br>

Cleaned Rows:
${cleanedRows.length}<br>

Removed Rows:
${removedRows}<br>

Final BOQ Rows:
${allRows.length}

`;

        }

    };

    reader.readAsArrayBuffer(file);

}