import { ParsedBOQItem } from "./boqReader";

export async function exportBOQDatabase(
    items: ParsedBOQItem[]
) {

    await Excel.run(async context => {

        let sheet =
            context.workbook.worksheets.getItemOrNullObject("_AI_BOQ_DATABASE");

        sheet.load("name");

        await context.sync();

        if (sheet.isNullObject) {

            sheet =
                context.workbook.worksheets.add("_AI_BOQ_DATABASE");

        } else {

            const used =
                sheet.getUsedRangeOrNullObject();

            used.load();

            await context.sync();

            if (!used.isNullObject) {

                used.clear();

            }

        }

        const data: any[][] = [];

        data.push([
            "Bill",
            "Section",
            "Item No",
            "Description",
            "Quantity",
            "Unit",
            "Rate",
            "Amount",
            "Sheet",
            "Row Type"
        ]);

        items.forEach(item => {

            data.push([
                item.bill,
                item.section,
                item.itemNo,
                item.description,
                item.quantity,
                item.unit,
                item.rate,
                item.amount,
                item.sheet,
                item.rowType
            ]);

        });

        const range =
            sheet.getRangeByIndexes(
                0,
                0,
                data.length,
                data[0].length
            );

        range.values = data;

        const header =
            sheet.getRange("A1:J1");

        header.format.font.bold = true;

        header.format.fill.color = "#1F4E78";

        header.format.font.color = "white";

        range.format.autofitColumns();

        range.format.autofitRows();

        await context.sync();

    });

}