import { ParsedBOQItem } from "./boqReader";

export interface Activity {

    activityId: string;

    activityName: string;

    wbs: string;

    quantity: number | null;

    unit: string;

}

export function generateActivities(
    items: ParsedBOQItem[]
): Activity[] {

    const activities: Activity[] = [];

    let counter = 10;

    items.forEach(item => {

        if (item.rowType !== "ITEM") {
            return;
        }

        activities.push({

            activityId:
                "A-" +
                String(counter).padStart(4, "0"),

            activityName:
                item.description,

            wbs:
                item.bill +
                " > " +
                item.section,

            quantity:
                item.quantity,

            unit:
                item.unit

        });

        counter += 10;

    });

    return activities;

}