import * as XLSX from "xlsx";


export interface BOQCell {

    value: any;

    formula?: string;

}


export interface BOQRow {

    sheet: string;

    rowNumber: number;

    cells: BOQCell[];

}
export type BOQRowType =
    | "ITEM"
    | "SECTION"
    | "BILL"
    | "SUMMARY"
    | "HEADER"
    | "EMPTY";

export interface ParsedBOQItem {

    sheet: string;

    rowNumber: number;

    rowType: BOQRowType;

    bill: string;

    itemNo: string;

    description: string;

    quantity: number | null;

    unit: string;

    rate: number | null;

    amount: number | null;

}

export function readBOQWorkbook(
    data: ArrayBuffer
): BOQRow[] {


    const workbook = XLSX.read(data,{
    type:"array",
    cellFormula:true,
    cellStyles:true,
    cellNF:true
});


    let allRows: BOQRow[] = [];


    workbook.SheetNames.forEach(sheetName => {


        const worksheet = workbook.Sheets[sheetName];


        const range = XLSX.utils.decode_range(
            worksheet["!ref"] || "A1"
        );


        for(
            let r = range.s.r;
            r <= range.e.r;
            r++
        ){


            let row: BOQCell[] = [];


            for(
                let c = range.s.c;
                c <= range.e.c;
                c++
            ){


                const address =
                    XLSX.utils.encode_cell({
                        r,
                        c
                    });


                const cell =
                    worksheet[address];


                if(cell){


                    row.push({

    value: cell.v,

    formula: cell.f || ""

});


                }
                else {


                    row.push({

                        value:""

                    });


                }


            }


            allRows.push({

                sheet: sheetName,

                rowNumber:r + 1,

                cells:row

            });


        }


    });


    return allRows;

}