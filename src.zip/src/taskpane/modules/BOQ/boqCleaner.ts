import { BOQRow } from "./boqReader";


export function cleanBOQRows(
    rows: BOQRow[]
): BOQRow[] {


    let removedCount = 0;


    const cleaned = rows.filter(row => {


        const values = row.cells.map(c =>
            String(c.value ?? "").trim()
        );


        const text = values
            .join(" ")
            .toLowerCase();



        // 1. Remove completely empty rows
        const filledCells = values.filter(v => v.trim() !== "").length;


        if(filledCells === 0){

            removedCount++;

            return false;
        }



        // 2. Remove page numbering
        if(
            /^page\s*\d+/i.test(text)
        ){

            removedCount++;

            return false;
        }



        // 3. Remove repeated column headers

        if(
            text.includes("item") &&
            text.includes("description") &&
            text.includes("quantity")
        ){

            removedCount++;

            return false;
        }



        // 4. Remove summary rows ONLY

        const summaryKeywords = [
            "carried to bill summary",
            "carried to collection",
            "total of page",
            "subtotal",
            "grand total"
        ];


        if(
            summaryKeywords.some(keyword =>
                text.includes(keyword)
            )
        ){

            console.log(
                "SUMMARY REMOVED:",
                row.sheet,
                row.rowNumber,
                text
            );


            removedCount++;

            return false;

        }



        return true;


    });



    console.log(
        "Cleaner Removed Rows:",
        removedCount
    );


    return cleaned;


}