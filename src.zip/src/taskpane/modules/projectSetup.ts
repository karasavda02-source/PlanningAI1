import { ExcelService } from "../services/ExcelService";
/* global Excel */

export function loadProjectSetup() {

    const container =
        document.getElementById("app");


    if (!container) return;


    container.innerHTML = `

    <div class="header">

<h1>PlanningAI</h1>

<p>
Project Management Assistant
</p>

</div>


<div class="card">

<div class="section-title">
Project Information
</div>


<div class="form-grid">


<div class="form-group">
<label>Project Name</label>
<input id="projectName">
</div>


<div class="form-group">
<label>Project Number</label>
<input id="projectNumber">
</div>


<div class="form-group">
<label>Client</label>
<input id="client">
</div>


<div class="form-group">
<label>Consultant</label>
<input id="consultant">
</div>


<div class="form-group">
<label>Contractor</label>
<input id="contractor">
</div>


<div class="form-group">
<label>Location</label>
<input id="location">
</div>


</div>

</div>


<div class="card">

<div class="section-title">
Schedule Information
</div>


<div class="form-grid">


<div class="form-group">
<label>Start Date</label>
<input type="date" id="startDate">
</div>


<div class="form-group">
<label>Finish Date</label>
<input type="date" id="finishDate">
</div>


<div class="form-group">
<label>Calendar</label>

<select id="calendar">

<option>5 Days</option>
<option selected>6 Days</option>
<option>7 Days</option>

</select>

</div>


<div class="form-group">
<label>Working Hours</label>

<input id="hours" value="10">

</div>


</div>

</div>



<div class="card">

<div class="section-title">
Activity Coding Structure
</div>


<div class="form-grid">


<div class="form-group">

<label>
Activity Prefix
</label>

<input id="prefix" value="ACT">

</div>


<div class="form-group">

<label>
Number Length
</label>

<input id="digits" value="5">

</div>


</div>


</div>


<div class="card">

<button id="createProject">
Create Project
</button>

<p id="setupMessage"></p>

</div>
    `;



    document
    .getElementById("createProject")
    ?.addEventListener(
        "click",
        createProject
    );

}



async function createProject() {


    const data = {


        projectName:
        getValue("projectName"),


        projectNumber:
        getValue("projectNumber"),


        client:
        getValue("client"),


        consultant:
        getValue("consultant"),


        contractor:
        getValue("contractor"),


        location:
        getValue("location"),


        startDate:
        getValue("startDate"),


        finishDate:
        getValue("finishDate"),


        calendar:
        getValue("calendar"),


        hours:
        getValue("hours"),


        prefix:
        getValue("prefix"),


        digits:
        getValue("digits")

    };



    await Excel.run(async(context)=>{


        const sheets =
        context.workbook.worksheets;



        const names = [

            "Project Dashboard",
            "_AI_Project",
            "_AI_Settings",
            "_AI_Activities",
            "_AI_WBS",
            "_AI_BOQ",
            "_AI_Resources",
            "_AI_Progress",
            "_AI_Log"

        ];



names.forEach(name => {
    sheets.add(name);
});






let sheet = sheets.getItem("Project Dashboard");
        sheet
        .getRange("A1:B12")
        .values=[

            ["PlanningAI Project",""],

            ["Project Name",data.projectName],

            ["Project Number",data.projectNumber],

            ["Client",data.client],

            ["Consultant",data.consultant],

            ["Contractor",data.contractor],

            ["Location",data.location],

            ["Start Date",data.startDate],

            ["Finish Date",data.finishDate],

            ["Calendar",data.calendar],

            ["Working Hours",data.hours],

            ["Activity Format",
            data.prefix+"-"+data.digits]

        ];



        await context.sync();


    });



    const msg =
    document.getElementById("setupMessage");


    if(msg)
    msg.textContent =
    "Project Created Successfully";

}



function getValue(id: string) {

    const element = document.getElementById(id) as HTMLInputElement;

    return element.value;

}