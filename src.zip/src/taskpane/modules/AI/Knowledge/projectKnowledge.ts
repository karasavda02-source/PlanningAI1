import { DocumentChunk } from "./documentChunk";


export class ProjectKnowledge {


    private chunks: DocumentChunk[] = [];


    add(

        chunk: DocumentChunk

    ) {

        this.chunks.push(chunk);

    }


    getAll(){

        return this.chunks;

    }


    clear(){

        this.chunks = [];

    }

}