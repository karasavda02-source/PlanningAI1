export class AIClient {


    private apiKey:string;


    constructor(apiKey:string){

        this.apiKey = apiKey;

    }



    async ask(prompt:string){


        const response = await fetch(
            "https://api.openai.com/v1/chat/completions",
            {

                method:"POST",

                headers:{

                    "Content-Type":"application/json",

                    "Authorization":
                    `Bearer ${this.apiKey}`

                },


                body:JSON.stringify({

                    model:"gpt-5",

                    messages:[

                        {

                            role:"system",

                            content:
                            `
                            You are a senior construction planning engineer.
                            Analyze BOQ, drawings and specifications.
                            Generate professional construction activities.
                            Do not guess.
                            Use engineering reasoning.
                            `

                        },

                        {

                            role:"user",

                            content:prompt

                        }

                    ],


                    temperature:0.2

                })

            }

        );


        const data = await response.json();


        return data.choices[0].message.content;


    }


}