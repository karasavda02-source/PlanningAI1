export interface PlanningResponse {

    wbs: any[];

    activities: any[];

    logic: any[];

    resources: any[];

    procurement: any[];

    inspections: any[];

}