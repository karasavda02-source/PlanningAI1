import { ConstructionReasoner } from "./constructionReasoner";


export class AIPlanner {

    private reasoner: ConstructionReasoner;


    constructor(){

       this.reasoner = new ConstructionReasoner();
    }


    async analyze(context: ProjectContext){

        return await this.reasoner.generateActivities({

            boq: context.boq

        });

    }

}