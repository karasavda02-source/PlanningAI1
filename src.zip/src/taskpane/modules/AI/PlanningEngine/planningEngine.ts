import { ProjectContext } from "../projectContext";
import { AIPlanner } from "./aiPlanner";


export class PlanningEngine {


    private planner: AIPlanner;


    constructor(){

        this.planner = new AIPlanner();

    }



    async analyzeProject(

        context: ProjectContext

    ){

        console.log(
            "Starting AI Project Analysis"
        );


        const result = await this.planner.analyze(

            context

        );


        console.log(
            "AI Analysis Result",
            result
        );


        return result;

    }


}