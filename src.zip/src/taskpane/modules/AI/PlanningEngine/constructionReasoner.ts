import { ActivityReasoningRequest } from "./activityReasoningRequest";


export class ConstructionReasoner {


    async generateActivities(

        request: ActivityReasoningRequest

    ) {


        console.log(
            "Construction Reasoning Started"
        );


        console.log(
            "BOQ Input:",
            request.boq.length
        );


        return request.boq.map((item, index)=>({

            id:
            "AI-A-" + (index + 1),

            name:
            item.description,

            quantity:
            item.quantity,

            unit:
            item.unit

        }));


    }


}