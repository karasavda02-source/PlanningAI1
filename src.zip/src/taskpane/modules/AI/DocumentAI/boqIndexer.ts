import { ParsedBOQItem } from "../../BOQ/boqReader";
import { DocumentChunk } from "../Knowledge/documentChunk";


export function indexBOQ(

    items: ParsedBOQItem[]

): DocumentChunk[] {


    return items.map((item, index) => {


        return {

            id: `BOQ-${index}`,

            source: "BOQ",

            page: 0,

            type: "BOQ",

            text:
`${item.bill}
${item.section ?? ""}
${item.description}`,

            metadata: {

                bill: item.bill,

                section: item.section

            }

        };


    });


}