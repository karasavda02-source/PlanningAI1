/* global Excel */

export class ExcelService {

    static async worksheetExists(name: string): Promise<boolean> {

        return Excel.run(async (context) => {

            const sheet = context.workbook.worksheets.getItemOrNullObject(name);
            sheet.load("name");

            await context.sync();

            return !sheet.isNullObject;
        });

    }

    static async createWorksheet(name: string): Promise<void> {

        return Excel.run(async (context) => {

            const sheet = context.workbook.worksheets.getItemOrNullObject(name);
            sheet.load("name");

            await context.sync();

            if (sheet.isNullObject) {
                context.workbook.worksheets.add(name);
            }

            await context.sync();

        });

    }

    static async hideWorksheet(name: string): Promise<void> {

        return Excel.run(async (context) => {

            const sheet = context.workbook.worksheets.getItem(name);

            sheet.visibility = Excel.SheetVisibility.hidden;

            await context.sync();

        });

    }

    static async activateWorksheet(name: string): Promise<void> {

        return Excel.run(async (context) => {

            const sheet = context.workbook.worksheets.getItem(name);

            sheet.activate();

            await context.sync();

        });

    }

    static async writeValues(
        sheetName: string,
        range: string,
        values: (string | number)[][]
    ): Promise<void> {

        return Excel.run(async (context) => {

            const sheet = context.workbook.worksheets.getItem(sheetName);

            sheet.getRange(range).values = values;

            await context.sync();

        });

    }

}