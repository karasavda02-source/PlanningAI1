/* global Office */

import { loadProjectSetup } 
from "./modules/projectSetup";
import { loadBOQPage } from "./modules/BOQ";


Office.onReady(()=>{


    const button =
    document.getElementById("projectSetup");


    button?.addEventListener(
        "click",
        ()=>{

            loadProjectSetup();

        }
    );
const boqButton = document.getElementById("boqImport");

boqButton?.addEventListener("click", () => {

    loadBOQPage();

});

});